use MooseX::Declare;

class My::Declare extends MooseX::Declare
{
    use Method::Signatures::Modifiers;

}
