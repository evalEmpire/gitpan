#!perl
use strict;
use warnings;
system "perl -MAcme::Buffy buffy";
