#!perl
use strict;
use warnings;
use Acme::Buffy;
BUffY bUFFY BUffY bUFFY bUfFy buffy BUFfy	buFFY BufFy	BufFY	bUFfy BuFFY buffy	bufFy bUffy bUffY BuFfy	BuffY	bUFfy BUfFY BUFFy	Buffy bUffY	BuFFY BUFFy	BufFy BUFfy BUfFY buFfy	BuffY	BuFfy	BUfFY bUffy	bufFy	buffY bUffy bUFfy	BuFFY	bUFfy	buFFY bufFy	buFfy BUffy	BUfFy bUFFy	buFfY BUffY bUfFy BUfFY	bufFy	buff