/* 18 */ extern uri_scheme_desc_t uri_scheme_ftp_desc; /* ftp */
/* 34 */ extern uri_scheme_desc_t uri_scheme_http_desc; /* http */
/* 35 */ extern uri_scheme_desc_t uri_scheme_https_desc; /* https */
/* 52 */ extern uri_scheme_desc_t uri_scheme_mailto_desc; /* mailto */
