/* 00 */ 	0,
/* 01 */ 	0,
/* 02 */ 	&uri_scheme_generic_desc,	/* tv */
/* 03 */ 	&uri_scheme_generic_desc,	/* sip */
/* 04 */ 	&uri_scheme_generic_desc,	/* sips */
/* 05 */ 	0,
/* 06 */ 	0,
/* 07 */ 	&uri_scheme_generic_desc,	/* service */
/* 08 */ 	0,
/* 09 */ 	&uri_scheme_file_desc,	/* file */
/* 10 */ 	0,
/* 11 */ 	0,
/* 12 */ 	&uri_scheme_generic_desc,	/* webster */
/* 13 */ 	&uri_scheme_generic_desc,	/* lrq */
/* 14 */ 	&uri_scheme_generic_desc,	/* h323 */
/* 15 */ 	0,
/* 16 */ 	0,
/* 17 */ 	0,
/* 18 */ 	&uri_scheme_ftp_desc,	/* ftp */
/* 19 */ 	&uri_scheme_generic_desc,	/* sipt */
/* 20 */ 	0,
/* 21 */ 	0,
/* 22 */ 	0,
/* 23 */ 	0,
/* 24 */ 	&uri_scheme_generic_desc,	/* h320 */
/* 25 */ 	0,
/* 26 */ 	0,
/* 27 */ 	0,
/* 28 */ 	&uri_scheme_generic_desc,	/* irc */
/* 29 */ 	&uri_scheme_news_desc,	/* news */
/* 30 */ 	0,
/* 31 */ 	0,
/* 32 */ 	0,
/* 33 */ 	0,
/* 34 */ 	&uri_scheme_http_desc,	/* http */
/* 35 */ 	&uri_scheme_https_desc,	/* https */
/* 36 */ 	0,
/* 37 */ 	0,
/* 38 */ 	0,
/* 39 */ 	&uri_scheme_generic_desc,	/* h324 */
/* 40 */ 	0,
/* 41 */ 	0,
/* 42 */ 	0,
/* 43 */ 	&uri_scheme_generic_desc,	/* sdp */
/* 44 */ 	&uri_scheme_generic_desc,	/* sipu */
/* 45 */ 	&uri_scheme_wais_desc,	/* wais */
/* 46 */ 	&uri_scheme_telnet_desc,	/* telnet */
/* 47 */ 	0,
/* 48 */ 	&uri_scheme_generic_desc,	/* videotex */
/* 49 */ 	&uri_scheme_generic_desc,	/* fax */
/* 50 */ 	0,
/* 51 */ 	&uri_scheme_generic_desc,	/* tn3270 */
/* 52 */ 	&uri_scheme_mailto_desc,	/* mailto */
/* 53 */ 	0,
/* 54 */ 	&uri_scheme_nntp_desc,	/* nntp */
/* 55 */ 	0,
/* 56 */ 	&uri_scheme_finger_desc,	/* finger */
/* 57 */ 	0,
/* 58 */ 	&uri_scheme_generic_desc,	/* pop */
/* 59 */ 	&uri_scheme_generic_desc,	/* pop3 */
/* 60 */ 	&uri_scheme_generic_desc,	/* whois */
/* 61 */ 	&uri_scheme_gopher_desc,	/* gopher */
/* 62 */ 	&uri_scheme_generic_desc,	/* whois++ */
/* 63 */ 	&uri_scheme_prospero_desc,	/* prospero */
/* 64 */ 	&uri_scheme_generic_desc,	/* smtp */
/* 65 */ 	&uri_scheme_snews_desc,	/* snews */
/* 66 */ 	0,
/* 67 */ 	0,
/* 68 */ 	0,
/* 69 */ 	&uri_scheme_generic_desc,	/* t120 */
/* 70 */ 	0,
/* 71 */ 	0,
/* 72 */ 	0,
/* 73 */ 	0,
/* 74 */ 	0,
/* 75 */ 	0,
/* 76 */ 	0,
/* 77 */ 	0,
/* 78 */ 	0,
/* 79 */ 	0,
/* 80 */ 	0,
/* 81 */ 	&uri_scheme_rlogin_desc,	/* rlogin */
/* 82 */ 	0,
/* 83 */ 	0,
/* 84 */ 	0,
/* 85 */ 	0,
/* 86 */ 	&uri_scheme_generic_desc,	/* rwhois */
/* 87 */ 	0,
/* 88 */ 	0,
/* 89 */ 	0,
/* 90 */ 	0,
/* 91 */ 	0,
/* 92 */ 	0,
/* 93 */ 	0,
/* 94 */ 	0,
/* 95 */ 	&uri_scheme_generic_desc,	/* phone */
/* 96 */ 	0,
/* 97 */ 	0,
/* 98 */ 	0,
/* 99 */ 	0,
/* 100 */ 	&uri_scheme_generic_desc,	/* modem */
