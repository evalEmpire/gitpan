
    $r = 0;

    for ($i = 0; $i < 100000; ++$i)
    {
	$r += 1;
    }

    print "r = $r\n";

    exit 0;
