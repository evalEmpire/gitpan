
use lib "./lib";

use stuff;

print "c = $stuff::c\n";
print "f() = ", stuff::f(), "\n";
