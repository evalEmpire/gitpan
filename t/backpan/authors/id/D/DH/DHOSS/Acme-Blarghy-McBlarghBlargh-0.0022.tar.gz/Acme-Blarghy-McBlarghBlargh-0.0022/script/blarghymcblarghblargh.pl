#!/usr/bin/perl 

use strict;
use Acme::Blarghy::McBlarghBlargh;

my $bbmbb = Acme::Blarghy::McBlarghBlargh->new;
print $bbmbb->blargh();
