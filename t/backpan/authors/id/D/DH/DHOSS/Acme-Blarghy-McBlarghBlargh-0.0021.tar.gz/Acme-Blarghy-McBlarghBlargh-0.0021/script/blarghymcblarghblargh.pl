#!/usr/bin/perl 

use strict;
use Acme::Blarghy::McBlarghBlargh;

print blargh();
