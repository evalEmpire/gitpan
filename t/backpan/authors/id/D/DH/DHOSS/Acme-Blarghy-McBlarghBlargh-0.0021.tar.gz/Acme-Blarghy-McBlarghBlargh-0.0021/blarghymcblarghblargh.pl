#!/usr/bin/perl 

use Acme::Blarghy::McBlarghBlargh;

print blargh();
