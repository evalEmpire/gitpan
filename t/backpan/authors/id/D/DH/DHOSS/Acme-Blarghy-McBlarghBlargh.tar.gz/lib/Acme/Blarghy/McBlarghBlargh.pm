package Acme::Blarghy::McBlarghBlargh;

1;
